// ModEntry.cs
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.GameData.Objects;
using StardewValley.Menus;

namespace TBoneHunter.LunchPail
{
    /// <summary>
    /// SMAPI entry point for Lunch Pail.
    /// Handles mod lifecycle, crafting recipe injection, save data,
    /// keybind input, and wiring of ConsumptionManager.
    /// </summary>
    public class ModEntry : Mod
    {
        // ----------------------------------------------------------------
        // Private state
        // ----------------------------------------------------------------

        private Config _config = null!;
        private LunchPailData _data = null!;
        private ConsumptionManager _consumptionManager = null!;

        private const string DataKey       = "tbonehunter.LunchPail/data";
        private const string UnlockItemId  = "tbonehunter.LunchPail_Unlock";
        private const string RecipeId      = "tbonehunter.LunchPail_Recipe";

        // ----------------------------------------------------------------
        // SMAPI Entry
        // ----------------------------------------------------------------

        public override void Entry(IModHelper helper)
        {
            _config = helper.ReadConfig<Config>();
            _data   = new LunchPailData();

            _consumptionManager = new ConsumptionManager(
                Monitor,
                () => _config,
                () => _data);

            helper.Events.GameLoop.GameLaunched   += OnGameLaunched;
            helper.Events.GameLoop.SaveLoaded     += OnSaveLoaded;
            helper.Events.GameLoop.Saving         += OnSaving;
            helper.Events.GameLoop.DayStarted     += OnDayStarted;
            helper.Events.GameLoop.UpdateTicked   += OnUpdateTicked;
            helper.Events.Input.ButtonPressed     += OnButtonPressed;
            helper.Events.Player.InventoryChanged += OnInventoryChanged;

            Monitor.Log("Lunch Pail loaded.", LogLevel.Debug);
        }

        // ----------------------------------------------------------------
        // GameLaunched: GMCM registration + asset injection
        // ----------------------------------------------------------------

        private void OnGameLaunched(object? sender, GameLaunchedEventArgs e)
        {
            ConfigMenu.Register(
                Helper,
                ModManifest,
                () => _config,
                config =>
                {
                    _config = config;
                    Helper.WriteConfig(config);
                });

            // Register asset edits here so they fire on every asset load,
            // not just once at launch.
            Helper.Events.Content.AssetRequested += OnAssetRequested;
        }

        // ----------------------------------------------------------------
        // Asset injection: unlock item + crafting recipe
        // ----------------------------------------------------------------

        private void OnAssetRequested(object? sender, AssetRequestedEventArgs args)
        {
            // ----------------------------------------------------------------
            // Register the unlock item using Stardew 1.6 ObjectData model.
            // The item is non-edible, zero value, and uses the error/litter
            // category so it does not appear in shops or gift tables.
            // ----------------------------------------------------------------
            if (args.Name.IsEquivalentTo("Data/Objects"))
            {
                args.Edit(asset =>
                {
                    var dict = asset.AsDictionary<string, ObjectData>().Data;
                    dict[UnlockItemId] = new ObjectData
                    {
                        Name        = UnlockItemId,
                        DisplayName = "Lunch Pail",
                        Description = "A handmade lunch pail. Use it to unlock auto-food management.",
                        Type        = "Basic",
                        Category    = StardewValley.Object.litterCategory,
                        Price       = 0,
                        Edibility   = -300 // not edible
                    };
                });
            }

            // ----------------------------------------------------------------
            // Register the crafting recipe.
            // Recipe string format (Stardew 1.6):
            //   "ItemId Count [ItemId Count ...]/ResultItemId/ResultCount/[Type]/[UnlockCondition]"
            // 771 = Fiber, 334 = Copper Bar.
            // Unlock condition "s Mining 1" = Mining skill level 1.
            // ----------------------------------------------------------------
            if (args.Name.IsEquivalentTo("Data/CraftingRecipes"))
            {
                args.Edit(asset =>
                {
                    var dict = asset.AsDictionary<string, string>().Data;
                    dict[RecipeId] =
                        $"771 50 334 1/Home/{UnlockItemId}/false/{RecipeId}/s Mining 1";
                });
            }
        }

        // ----------------------------------------------------------------
        // Save data
        // ----------------------------------------------------------------

        private void OnSaveLoaded(object? sender, SaveLoadedEventArgs e)
        {
            _data = Helper.Data.ReadSaveData<LunchPailData>(DataKey)
                ?? new LunchPailData();

            _consumptionManager.ResetSession();
            Monitor.Log(
                $"[LunchPail] Save data loaded. HasLunchPail={_data.HasLunchPail}",
                LogLevel.Debug);
        }

        private void OnSaving(object? sender, SavingEventArgs e)
        {
            Helper.Data.WriteSaveData(DataKey, _data);
            Monitor.Log("[LunchPail] Save data written.", LogLevel.Debug);
        }

        // ----------------------------------------------------------------
        // Day started
        // ----------------------------------------------------------------

        private void OnDayStarted(object? sender, DayStartedEventArgs e)
        {
            _consumptionManager.ResetSession();
        }

        // ----------------------------------------------------------------
        // Update tick
        // ----------------------------------------------------------------

        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            _consumptionManager.OnUpdateTicked(e);
        }

        // ----------------------------------------------------------------
        // Keybind: open UI
        // ----------------------------------------------------------------

        private void OnButtonPressed(object? sender, ButtonPressedEventArgs e)
        {
            if (!Context.IsWorldReady) return;
            if (!_data.HasLunchPail) return;
            if (Game1.activeClickableMenu != null) return;

            if (_config.OpenLunchPailKey.JustPressed())
            {
                Game1.activeClickableMenu = new LunchPailUI(Monitor, _data, () => _config);
            }
        }

        // ----------------------------------------------------------------
        // Inventory changed: watch for unlock item being used/consumed
        // ----------------------------------------------------------------

        private void OnInventoryChanged(object? sender, InventoryChangedEventArgs e)
        {
            if (_data.HasLunchPail) return;

            foreach (var item in e.Removed)
            {
                if (item.QualifiedItemId == $"(O){UnlockItemId}")
                {
                    ActivateLunchPail();
                    return;
                }
            }
        }

        // ----------------------------------------------------------------
        // Activation: set flag, save immediately, show dialogue
        // ----------------------------------------------------------------

        private void ActivateLunchPail()
        {
            _data.HasLunchPail = true;
            Helper.Data.WriteSaveData(DataKey, _data);

            Game1.activeClickableMenu = new DialogueBox(
                "You've assembled your Lunch Pail! Food in your inventory can now be " +
                "designated for auto-consumption. Press " +
                $"{_config.OpenLunchPailKey} to manage your Lunch Pail.");

            Monitor.Log("[LunchPail] Lunch Pail activated for player.", LogLevel.Info);
        }
    }
}
